@echo off
chcp 65001 > nul
title Municipal GIS - Running for ALL Devices
cls
echo.
echo  =====================================================
echo   MUNICIPAL GIS ENCROACHMENT DETECTION SYSTEM
echo  =====================================================
echo.
echo   SERVER IS STARTING...
echo.
echo   [THIS LAPTOP]
echo   http://127.0.0.1:5000
echo.
echo   [ALL OTHER LAPTOPS and PHONES on same Wi-Fi]
echo   http://10.226.235.49:5000
echo.
echo   [CONNECT PAGE with QR CODE - scan from phone]
echo   http://10.226.235.49:5000/connect
echo.
echo   Default login:  admin / Admin@1234
echo   Sign up:        http://10.226.235.49:5000/signup
echo  =====================================================
echo.
echo   NOTE: Keep this window open while others connect.
echo   Press Ctrl+C to stop the server.
echo.

cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
python run_app.py

pause
