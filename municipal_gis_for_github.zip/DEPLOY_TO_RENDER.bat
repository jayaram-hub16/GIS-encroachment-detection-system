@echo off
chcp 65001 > nul
title Municipal GIS - GitHub Upload Tool
cls
echo.
echo  ========================================================
echo   STEP 1: Upload your project to GitHub (required once)
echo   Then Render.com will auto-deploy it permanently.
echo  ========================================================
echo.
echo  This script creates a ZIP of your project
echo  that you can upload to GitHub directly via browser.
echo.

set "PROJECT_DIR=%~dp0"
set "ZIP_OUT=C:\Users\jeten\Downloads\municipal_gis_for_github.zip"

:: Remove old zip if exists
if exist "%ZIP_OUT%" del "%ZIP_OUT%"

echo  [*] Creating project ZIP...
powershell -Command ^
  "Compress-Archive -Path '%PROJECT_DIR%*' -DestinationPath '%ZIP_OUT%' ^
   -CompressionLevel Optimal" 2>&1

if exist "%ZIP_OUT%" (
    echo.
    echo  [SUCCESS] ZIP created: %ZIP_OUT%
    echo.
    echo  =====================================================
    echo   NEXT STEPS TO GET PUBLIC HTTPS URL:
    echo  =====================================================
    echo.
    echo  1. Go to: https://github.com/new
    echo     Create a NEW repository named: municipal-gis-system
    echo     Visibility: Public
    echo     (Do NOT add README or .gitignore - leave blank)
    echo.
    echo  2. After creating repo, click "uploading an existing file"
    echo     Upload the ZIP file at:
    echo     %ZIP_OUT%
    echo     Then click "Commit changes"
    echo.
    echo  3. Go to: https://render.com/
    echo     Sign up with your GitHub account
    echo     Click "New" -> "Web Service"
    echo     Connect your GitHub repo
    echo.
    echo  4. Render auto-detects render.yaml and deploys!
    echo     Your public URL will be:
    echo     https://municipal-gis-system.onrender.com
    echo.
    echo  =====================================================
    echo.
    
    :: Open GitHub new repo page
    start "" "https://github.com/new"
    timeout /t 2 > nul
    :: Open the ZIP location
    explorer /select,"%ZIP_OUT%"
) else (
    echo  [ERROR] ZIP creation failed.
)

echo.
pause
