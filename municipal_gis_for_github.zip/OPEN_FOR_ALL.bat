@echo off
:: This file opens the app for ALL laptops on the same Wi-Fi network.
:: Run it ONCE as Administrator to allow other devices to connect.

echo.
echo ============================================
echo  Municipal GIS - Open For ALL Devices
echo ============================================
echo.

:: Check if running as Administrator
net session >nul 2>&1
if %errorLevel% == 0 (
    echo [OK] Running as Administrator
    goto ADD_FIREWALL
) else (
    echo [INFO] Requesting Administrator access...
    powershell -Command "Start-Process cmd -ArgumentList '/c, \"%~f0\"' -Verb RunAs"
    exit /b
)

:ADD_FIREWALL
:: Remove old rule if exists, then add fresh
netsh advfirewall firewall delete rule name="MuniGIS Port 5000" >nul 2>&1
netsh advfirewall firewall add rule name="MuniGIS Port 5000" dir=in action=allow protocol=TCP localport=5000
echo [OK] Firewall rule added - Port 5000 is now open on your network!
echo.

:: Get this machine's IP address
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /r "IPv4"') do (
    set IP=%%a
    goto FOUND_IP
)
:FOUND_IP
set IP=%IP: =%

echo ============================================
echo  SHARE THIS LINK WITH ALL LAPTOPS/PHONES:
echo.
echo    http://%IP%:5000
echo.
echo  All devices must be on the SAME Wi-Fi!
echo ============================================
echo.

:: Start the application server
echo [*] Starting the application server...
echo [*] Do NOT close this window!
echo.
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
python run_app.py

pause
